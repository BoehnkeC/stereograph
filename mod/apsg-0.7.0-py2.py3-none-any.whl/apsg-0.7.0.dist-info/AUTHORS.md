# Credits

## Development Lead

* Ondrej Lexa <lexa.ondrej@gmail.com>

## Contributors

* David Landa <david.landa@natur.cuni.cz>
